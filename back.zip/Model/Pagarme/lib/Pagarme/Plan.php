<?php

class PagarMe_Plan extends PagarMe_Model {
}
