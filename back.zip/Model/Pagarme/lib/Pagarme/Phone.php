<?php

class PagarMe_Phone extends PagarMe_Model {

}
