<?php

class PagarMe_Bank_Account extends PagarMe_Model {
}
