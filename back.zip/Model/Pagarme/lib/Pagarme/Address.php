<?php

class PagarMe_Address extends PagarMe_Model {
}
