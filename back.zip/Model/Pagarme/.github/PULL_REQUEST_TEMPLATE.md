### Descrição

<!Insira aqui o contexto/motivo deste Pull Request.>

### Número da Issue

<!Insira aqui o número da Issue referente à este Pull Request.>

### Testes Realizados

<!Descreva aqui todos os detalhes realizados para assegurar o Pull Request. Coloque todos os dados possíveis: versões dos recursos, módulos extras adicionados ao teste :)>

<!NÃO SE ESQUEÇA DE: Marcar um dos desenvolvedores do Pagar.me para review.>
