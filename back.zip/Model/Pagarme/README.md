pagarme-php
===========

Pagar.me's PHP API

[![Build Status](https://travis-ci.org/pagarme/pagarme-php.png?branch=master)](https://travis-ci.org/pagarme/pagarme-php)

## Support
If you have any problem or suggestion please open an issue [here](https://github.com/pagarme/pagarme-php/issues).

## License

Check [here](LICENSE).
