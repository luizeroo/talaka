<html>

<head>
    <meta charset="UTF-8">
    <title> Error - 404 </title>
    <link href="/view/css/style.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Roboto:100,400,700" rel="stylesheet">
</head>

<body style='background-color:#fff'>
<div id='container' class='bg'>
    <div class='wrapper' style='width:900px'>
        <div class='error'>
            <h1>
                Ooops!
            </h1>
            <h2>Nós não conseguimos achar a página que você estava procurando no Talaka.</h2>
            <h3>Código de erro: 404</h3>
            <p> Volte a página <a href='/'>Inicial</a></p>
        </div>
        <div class='char'></div>
    </div>
</div>
</body>