<?php
defined("System-access") or header('location: /error');
?>
<footer>
    <ul>
        <li></li>
        <li></li>
        <li></li>
        <p><b>Desenvolvedores</b>
            <br> Gustavo Rosario, José Luiz Reis e Lucas Teixeira</p>
        <p>Talaka. 2017.</p>
    </ul>
</footer>