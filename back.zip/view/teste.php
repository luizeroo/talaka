<!--
<form action="/teste2" method="POST" enctype="multipart/form-data">
    <input type="file" name="img">
    <input type="submit" value="testar">
</form>
<!DOCTYPE html>
<html>
    
<head>
    <style type="text/css">
        body{
            background-image: url("../view/first.svg");
            background-size: cover;
            width:100%;
            height:100%;
            
        }
    </style>
</head>
<body>
</body>
</html>


-->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<style>
			*{
				margin: 0;
				padding: 0;
			}
			body{
				width: 100%;
				height: 100%;
				background-image: url("../view/first.svg");
				background-repeat: no-repeat;
				background-size: cover;
				background-position-y: 0px;
			}
			
		</style>
		
		<style type="text/css" media="only screen and (min-width: 1200px) and (max-width: 1249px)">
				body{
					background-position-y: 0;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1250px) and (max-width: 1279px)">
				body{
					background-position-y: -33px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1280px) and (max-width: 1299px)">
				body{
					background-position-y: -42px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1300px) and (max-width: 1349px)">
				body{
					background-position-y: -75px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1350px) and (max-width: 1399px)">
				body{
					background-position-y: -95px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1400px) and (max-width: 1439px)">
				body{
					background-position-y: -115px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1440px) and (max-width: 1459px)">
				body{
					background-position-y: -135px;
				}
		</style>
		<style type="text/css" media="only screen and (min-width: 1460px)">
				body{
					background-position-y: -171px;
				}
		</style>
		
	</head>
	<body>
	
		
		
		<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
      	<script type="text/javascript" src="js/materialize.min.js"></script>
	</body>
</html>