<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link href="/view/css/reworkStyle.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Berkshire+Swash" rel="stylesheet">
    <title> Perfil </title>
</head>

    <body>
        <nav>
            <div id="logo">
                Talaka
            </div>
            <div id="search_categories">
                Categorias
                <ul>
                    <li></li>
                </ul>
            </div>
            <div id="start_campaign">
                Começar campanha
            </div>
            <div id="search">
                <button id="search_icon"></button>
                <input type="text" placeholder="Buscar projetos">
            </div>
            <div id="store">
                store
            </div>
            <div id="signin">
                Acessar
            </div>
            <div id="signup">
                Cadastre-se
            </div>
        </nav>
        <div id="cover"></div>
        <main class="mainMargin" id="mainProfile">
            <div id="profilePhoto"></div>
            <div id="profileInfos">
                <h1>José Luiz Reis Oliveira</h1>
                <h2>Ilustrador / Desenvolvedor Web </h2>
                <ul id="profileButtons">
                    <li id="follow"></li>
                    <li id="message"></li>
                    <li id="patreon"></li>
                </ul>

                <ul id="profileNetwork">
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>

                <h3>Praia Grande - São Paulo</h3>
                <h3>http://www.talaka.com</h3>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor. Fusce euismod dolor aliquam justo accumsan, ac laoreet turpis lobortis. Nunc vestibulum magna nunc, a sollicitudin lacus lobortis sit amet. Vivamus elit felis, imperdiet at vehicula nec, fringilla sit amet tellus. Suspendisse enim arcu, faucibus in massa vel, imperdiet cursus enim. Integer ut sagittis sapien, et ultrices magna. Nullam ornare tortor magna, at auctor turpis aliquet et. Mauris eu ullamcorper leo. Etiam tincidunt tincidunt auctor.
                </p>
            </div>
            
            <ul id="profileSections">
                <li>
                    <div class="icon" id="profileCreated"></div>
                </li>
                <li>
                    <div class="icon" id="profileFinanced"></div>
                </li>
                <li>
                    <div class="icon" id="profileFollowers"></div>
                </li>
                <li>
                    <div class="icon" id="profilePortfolio"></div>
                </li>
            </ul>
            <div class="profileMain">
                <div id="profileProjects">
                    <h2>Últimos projetos</h2>
                    <div class="eachProject">
                        <div class="projectCover">
                            <div class="projectOwner"></div>
                        </div>
                        <div class="projectDescription">
                            <p class="projectTag">
                                <span>icon</span> Gênero do Quadrinho
                            </p>
                            
                            <p class="projectTitle">
                                Título do Quadrinho
                            </p>
                            
                            <p class="projectInfos">
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor.
                            </p>
                        </div>
                        <div class="projectStatus">
                            <p class="projectFinanced">
                                <b>R$ 3.312,00</b> acumulados
                            </p>
                            <div class="progressbar">
                                <div class="progressValue"></div>
                            </div>
                            <p class="projectPercent">
                                64%
                            </p>
                            <p class="projectDate">
                                Aberto até 25/11/2017
                            </p>
                       </div>
                    </div>
                     
                     <div class="eachProject">
                        <div class="projectCover">
                            <div class="projectOwner"></div>
                        </div>
                        <div class="projectDescription">
                            <p class="projectTag">
                                <span>icon</span> Gênero do Quadrinho
                            </p>
                            
                            <p class="projectTitle">
                                Título do Quadrinho
                            </p>
                            
                            <p class="projectInfos">
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor.
                            </p>
                        </div>
                        <div class="projectStatus">
                            <p class="projectFinanced">
                                <b>R$ 3.312,00</b> acumulados
                            </p>
                            <div class="progressbar">
                                <div class="progressValue"></div>
                            </div>
                            <p class="projectPercent">
                                64%
                            </p>
                            <p class="projectDate">
                                Aberto até 25/11/2017
                            </p>
                       </div>
                    </div>
                    
                    <div class="eachProject">
                        <div class="projectCover">
                            <div class="projectOwner"></div>
                        </div>
                        <div class="projectDescription">
                            <p class="projectTag">
                                <span>icon</span> Gênero do Quadrinho
                            </p>
                            
                            <p class="projectTitle">
                                Título do Quadrinho
                            </p>
                            
                            <p class="projectInfos">
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor.
                            </p>
                        </div>
                        <div class="projectStatus">
                            <p class="projectFinanced">
                                <b>R$ 3.312,00</b> acumulados
                            </p>
                            <div class="progressbar">
                                <div class="progressValue"></div>
                            </div>
                            <p class="projectPercent">
                                64%
                            </p>
                            <p class="projectDate">
                                Aberto até 25/11/2017
                            </p>
                       </div>
                    </div>
                    
                    <div class="eachProject">
                        <div class="projectCover">
                            <div class="projectOwner"></div>
                        </div>
                        <div class="projectDescription">
                            <p class="projectTag">
                                <span>icon</span> Gênero do Quadrinho
                            </p>
                            
                            <p class="projectTitle">
                                Título do Quadrinho
                            </p>
                            
                            <p class="projectInfos">
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor.
                            </p>
                        </div>
                        <div class="projectStatus">
                            <p class="projectFinanced">
                                <b>R$ 3.312,00</b> acumulados
                            </p>
                            <div class="progressbar">
                                <div class="progressValue"></div>
                            </div>
                            <p class="projectPercent">
                                64%
                            </p>
                            <p class="projectDate">
                                Aberto até 25/11/2017
                            </p>
                       </div>
                    </div>
                </div>

                <div id="profileStatus">
                    <div class="profileEachStatus">
                        <h2>Status</h2>
                        <table>
                            <tr>
                                <td>19</td>
                                <td>Projetos Criados</td>
                            </tr>
                            <tr>
                                <td>12</td>
                                <td>Apoiados</td>
                            </tr>
                            <tr>
                                <td>331</td>
                                <td>Seguidores</td>
                            </tr>
                            <tr>
                                <td>132</td>
                                <td>Apoiadores</td>
                            </tr>
                        </table>
                    </div>

                    <div class="profileEachStatus">
                        <h2>Sobre o meu trabalho</h2>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus quis dui pellentesque, fringilla velit eget, pellentesque mauris. Mauris elementum vitae metus sed porttitor.
                        </p>
                    </div>

                    <div class="profileEachStatus" id="profileTag">
                        <h2>Gêneros principais</h2>
                        <a href="#"><span>Ação</span></a>
                        <span>Ficção Cientifica</span> </a>
                        <span>História</span> </a>
                        <span>Biográfico</span></a>
                        <span>Comédia</span> </a>
                        <span>Drama</span></a>
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>